const formatter = new Intl.NumberFormat('tr-TR', {
  style: 'currency',
  currency: 'TRY',
  maximumFractionDigits: 0
});

const numberFormatter = new Intl.NumberFormat('tr-TR');

const goalLabels = {
  awareness: 'Bilinirlik',
  sales: 'Satış',
  traffic: 'Web site trafiği',
  social: 'Sosyal medya büyütme',
  launch: 'Ürün lansmanı',
  local: 'Yerel işletme tanıtımı'
};

const sectorLabels = {
  ecommerce: 'E-ticaret',
  restaurant: 'Kafe / restoran',
  fashion: 'Giyim / moda',
  education: 'Eğitim',
  technology: 'Teknoloji',
  beauty: 'Güzellik / kuaför',
  event: 'Etkinlik',
  localService: 'Yerel hizmet'
};

const basePlans = {
  awareness: {
    'Instagram Ads': 25,
    'TikTok Ads': 25,
    'YouTube Ads': 25,
    'Display Ads': 15,
    'Google Search': 10
  },
  sales: {
    'Google Search': 30,
    'Instagram Ads': 25,
    'Remarketing': 20,
    'TikTok Ads': 15,
    'YouTube Ads': 10
  },
  traffic: {
    'Google Search': 30,
    'Instagram Ads': 20,
    'Display Ads': 20,
    'YouTube Ads': 15,
    'TikTok Ads': 15
  },
  social: {
    'Instagram Ads': 35,
    'TikTok Ads': 30,
    'Influencer': 15,
    'YouTube Shorts': 10,
    'Remarketing': 10
  },
  launch: {
    'TikTok Ads': 25,
    'Instagram Ads': 25,
    'YouTube Ads': 25,
    'Influencer': 15,
    'Google Search': 10
  },
  local: {
    'Instagram Ads': 35,
    'Google Maps/Search': 30,
    'TikTok Ads': 15,
    'Açık Hava': 10,
    'Remarketing': 10
  }
};

const channelBenchmarks = {
  'Instagram Ads': { cpm: 65, cpc: 5.5 },
  'TikTok Ads': { cpm: 55, cpc: 4.8 },
  'YouTube Ads': { cpm: 70, cpc: 6.5 },
  'YouTube Shorts': { cpm: 58, cpc: 5.2 },
  'Display Ads': { cpm: 45, cpc: 4.2 },
  'Google Search': { cpm: 90, cpc: 9.5 },
  'Google Maps/Search': { cpm: 80, cpc: 7.5 },
  'Remarketing': { cpm: 50, cpc: 4.0 },
  'Influencer': { cpm: 85, cpc: 8.5 },
  'Açık Hava': { cpm: 35, cpc: 0 }
};

const channelColors = [
  '#2563eb', '#7c3aed', '#0f9f6e', '#f59e0b', '#ef4444', '#0891b2', '#111827'
];

let chart;

function clonePlan(plan) {
  return JSON.parse(JSON.stringify(plan));
}

function adjustPlan(plan, sector, audience) {
  const adjusted = clonePlan(plan);

  function add(channel, amount) {
    adjusted[channel] = (adjusted[channel] || 0) + amount;
  }

  if (['13-18', '18-24'].includes(audience)) {
    add('TikTok Ads', 6);
    add('Instagram Ads', 4);
  }

  if (['35-44', '45+'].includes(audience)) {
    add('Google Search', 5);
    add('YouTube Ads', 4);
  }

  if (sector === 'restaurant' || sector === 'localService' || sector === 'beauty') {
    add('Google Maps/Search', 7);
    add('Instagram Ads', 4);
  }

  if (sector === 'ecommerce') {
    add('Remarketing', 6);
    add('Google Search', 4);
  }

  if (sector === 'fashion') {
    add('Instagram Ads', 7);
    add('TikTok Ads', 4);
  }

  if (sector === 'education' || sector === 'technology') {
    add('Google Search', 6);
    add('YouTube Ads', 4);
  }

  return normalizePlan(adjusted);
}

function normalizePlan(plan) {
  const entries = Object.entries(plan).filter(([, value]) => value > 0);
  const total = entries.reduce((sum, [, value]) => sum + value, 0);
  const normalized = entries.map(([channel, value]) => ({
    channel,
    percent: value / total * 100
  }));

  let rounded = normalized.map(item => ({ ...item, percent: Math.round(item.percent) }));
  let diff = 100 - rounded.reduce((sum, item) => sum + item.percent, 0);
  rounded.sort((a, b) => b.percent - a.percent);

  let i = 0;
  while (diff !== 0 && rounded.length > 0) {
    rounded[i % rounded.length].percent += diff > 0 ? 1 : -1;
    diff += diff > 0 ? -1 : 1;
    i++;
  }

  return rounded.filter(item => item.percent > 0).sort((a, b) => b.percent - a.percent);
}

function createPlan() {
  const budget = Math.max(Number(document.getElementById('budget').value || 0), 0);
  const goal = document.getElementById('goal').value;
  const sector = document.getElementById('sector').value;
  const audience = document.getElementById('audience').value;
  const duration = Number(document.getElementById('duration').value);

  const allocation = adjustPlan(basePlans[goal], sector, audience);
  const rows = allocation.map(item => {
    const channelBudget = budget * item.percent / 100;
    const benchmark = channelBenchmarks[item.channel] || { cpm: 60, cpc: 6 };
    const impressions = benchmark.cpm > 0 ? (channelBudget / benchmark.cpm) * 1000 : 0;
    const clicks = benchmark.cpc > 0 ? channelBudget / benchmark.cpc : 0;
    return {
      ...item,
      budget: channelBudget,
      cpm: benchmark.cpm,
      cpc: benchmark.cpc,
      impressions,
      clicks
    };
  });

  const totalImpressions = rows.reduce((sum, row) => sum + row.impressions, 0);
  const totalClicks = rows.reduce((sum, row) => sum + row.clicks, 0);
  const avgCpm = totalImpressions > 0 ? budget / totalImpressions * 1000 : 0;
  const avgCpc = totalClicks > 0 ? budget / totalClicks : 0;
  const ctr = totalImpressions > 0 ? totalClicks / totalImpressions * 100 : 0;
  const dailyBudget = budget / duration;

  renderResults({ budget, goal, sector, audience, duration, rows, totalImpressions, totalClicks, avgCpm, avgCpc, ctr, dailyBudget });
}

function renderResults(data) {
  document.getElementById('resultTitle').textContent = `${goalLabels[data.goal]} kampanyası planı`;

  const table = document.getElementById('allocationTable');
  table.innerHTML = data.rows.map(row => `
    <tr>
      <td><strong>${row.channel}</strong></td>
      <td>%${row.percent}</td>
      <td>${formatter.format(row.budget)}</td>
      <td>${row.clicks > 0 ? numberFormatter.format(Math.round(row.clicks)) : 'Ölçülmez'}</td>
    </tr>
  `).join('');

  document.getElementById('stats').innerHTML = `
    <div class="stat"><span>Tahmini gösterim</span><strong>${numberFormatter.format(Math.round(data.totalImpressions))}</strong></div>
    <div class="stat"><span>Tahmini tıklama</span><strong>${numberFormatter.format(Math.round(data.totalClicks))}</strong></div>
    <div class="stat"><span>Ortalama CPC</span><strong>${data.avgCpc ? data.avgCpc.toFixed(2) + ' TL' : '-'}</strong></div>
    <div class="stat"><span>Günlük bütçe</span><strong>${formatter.format(data.dailyBudget)}</strong></div>
  `;

  renderInsights(data);
  renderWeeklyPlan(data);
  updateChart(data.rows);
  renderReport(data);
}

function updateChart(rows) {
  const ctx = document.getElementById('budgetChart');
  const labels = rows.map(row => row.channel);
  const values = rows.map(row => row.percent);

  if (typeof Chart === 'undefined') {
    ctx.style.display = 'none';
    return;
  }

  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: channelColors,
        borderWidth: 0,
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'bottom' },
        tooltip: {
          callbacks: {
            label: context => `${context.label}: %${context.raw}`
          }
        }
      },
      cutout: '62%'
    }
  });
}

function renderInsights(data) {
  const strongestChannel = data.rows[0];
  const measurableRows = data.rows.filter(row => row.clicks > 0);
  const bestCpc = measurableRows.length ? measurableRows.reduce((best, row) => row.cpc < best.cpc ? row : best, measurableRows[0]) : null;
  const budgetHealth = data.budget < 10000 ? 'Düşük bütçede kanal sayısını azaltıp 2-3 ana kanala odaklanmak daha mantıklı olabilir.' : data.budget < 50000 ? 'Orta bütçede test + optimizasyon dengesi kurulabilir.' : 'Bu bütçe ile hem erişim hem dönüşüm odaklı çok kanallı test yapılabilir.';

  document.getElementById('insights').innerHTML = `
    <div class="insight-card">
      <span>En güçlü kanal</span>
      <strong>${strongestChannel.channel} / %${strongestChannel.percent}</strong>
      <p>${channelReason(strongestChannel.channel, data.goal, data.sector)}</p>
    </div>
    <div class="insight-card">
      <span>En uygun tıklama</span>
      <strong>${bestCpc ? bestCpc.channel + ' / ' + bestCpc.cpc.toFixed(2) + ' TL' : 'Ölçülmez'}</strong>
      <p>Tıklama maliyeti düşük kanallar test bütçesi için avantaj sağlayabilir.</p>
    </div>
    <div class="insight-card">
      <span>Bütçe yorumu</span>
      <strong>${formatter.format(data.dailyBudget)} / gün</strong>
      <p>${budgetHealth}</p>
    </div>
  `;
}

function renderWeeklyPlan(data) {
  const weeklyBudget = data.budget / Math.max(Math.ceil(data.duration / 7), 1);
  const weeks = [
    ['1. Hafta', 'Kreatif testleri, hedef kitle denemeleri ve ilk veri toplama süreci.'],
    ['2. Hafta', 'En iyi çalışan kanal, reklam metni ve görsellerin bütçesini artırma.'],
    ['3. Hafta', 'Remarketing, dönüşüm odaklı kampanyalar ve düşük verimli kanalları azaltma.'],
    ['4. Hafta', 'Performans raporu, bütçe optimizasyonu ve sonraki kampanya için öğrenimleri çıkarma.']
  ];

  document.getElementById('weeklyPlan').innerHTML = `
    <p class="mini-title">Haftalık uygulama planı</p>
    ${weeks.map(([week, text]) => `
      <div class="weekly-item">
        <strong>${week}</strong>
        <p>${text} Ortalama haftalık bütçe: <strong>${formatter.format(weeklyBudget)}</strong>.</p>
      </div>
    `).join('')}
  `;
}

function channelReason(channel, goal, sector) {
  if (channel.includes('Google')) return 'Arama niyeti yüksek kullanıcıları yakalamak için özellikle satış, trafik ve yerel hizmetlerde güçlüdür.';
  if (channel.includes('Instagram')) return 'Görsel içerik, ürün keşfi ve yerel marka görünürlüğü için dengeli bir ana kanaldır.';
  if (channel.includes('TikTok')) return 'Genç kitle, kısa video ve hızlı erişim hedeflerinde güçlü bir test kanalıdır.';
  if (channel.includes('YouTube')) return 'Video ile bilinirlik ve açıklayıcı içerik anlatımı için uygundur.';
  if (channel.includes('Remarketing')) return 'Daha önce ilgi göstermiş kullanıcıları tekrar hedefleyerek dönüşüm ihtimalini artırır.';
  if (channel.includes('Influencer')) return 'Güven, sosyal kanıt ve hızlı ürün tanıtımı için destekleyici kanal olarak kullanılabilir.';
  return 'Bu kanal kampanya karmasını tamamlayıcı rol oynar.';
}

function renderReport(data) {
  const topChannels = data.rows.slice(0, 3).map(row => row.channel).join(', ');
  const young = ['13-18', '18-24'].includes(data.audience);
  const report = `
    <p><strong>${formatter.format(data.budget)}</strong> bütçeli, <strong>${data.duration} günlük</strong> ${goalLabels[data.goal].toLowerCase()} kampanyası için önerilen ana medya kanalları <strong>${topChannels}</strong> olarak belirlenmiştir.</p>

    <h4>Strateji yorumu</h4>
    <p>${goalStrategyText(data.goal)} ${sectorStrategyText(data.sector)} ${young ? 'Genç hedef kitle seçildiği için TikTok ve Instagram ağırlığı artırılmıştır.' : 'Hedef kitle daha geniş yaş aralığında olduğu için Google ve YouTube kanallarına daha fazla önem verilmiştir.'}</p>

    <h4>Tahmini performans</h4>
    <p>Bu plana göre yaklaşık <strong>${numberFormatter.format(Math.round(data.totalImpressions))}</strong> gösterim ve <strong>${numberFormatter.format(Math.round(data.totalClicks))}</strong> tıklama elde edilebilir. Ortalama CPC yaklaşık <strong>${data.avgCpc.toFixed(2)} TL</strong>, ortalama CPM ise yaklaşık <strong>${data.avgCpm.toFixed(2)} TL</strong> seviyesindedir.</p>

    <h4>Kanal öncelikleri</h4>
    <ul>
      ${data.rows.slice(0, 5).map(row => `<li><strong>${row.channel}:</strong> Bütçenin %${row.percent} oranı, yaklaşık ${formatter.format(row.budget)}.</li>`).join('')}
    </ul>

    <p class="notice"><strong>Uyarı:</strong> Bu rapor tahmini medya planlama simülasyonudur. Gerçek sonuçlar reklam kreatifi, hedefleme, rekabet, sezon, ürün fiyatı ve web sitesi kalitesine göre değişebilir.</p>
  `;
  document.getElementById('strategyReport').innerHTML = report;
}

function goalStrategyText(goal) {
  const texts = {
    awareness: 'Bilinirlik hedefi seçildiği için erişim ve video görünürlüğü güçlü kanallara ağırlık verilmiştir.',
    sales: 'Satış hedefi seçildiği için satın alma niyeti yüksek Google Search ve tekrar hedefleme kanalları güçlendirilmiştir.',
    traffic: 'Trafik hedefi seçildiği için tıklama maliyeti dengeli kanallar ve arama ağı birlikte kullanılmıştır.',
    social: 'Sosyal medya büyütme hedefi seçildiği için etkileşim ve takipçi kazanımı güçlü platformlar öne çıkarılmıştır.',
    launch: 'Lansman hedefi seçildiği için video, sosyal medya ve influencer destekli bir görünürlük karması önerilmiştir.',
    local: 'Yerel tanıtım hedefi seçildiği için Google Maps/Search ve Instagram gibi konum bazlı güçlü kanallar öne çıkarılmıştır.'
  };
  return texts[goal] || '';
}

function sectorStrategyText(sector) {
  const texts = {
    ecommerce: 'E-ticaret sektörü için dönüşüm ve remarketing bütçesi kritik görülmüştür.',
    restaurant: 'Kafe/restoran işletmeleri için yakın çevre, görsel içerik ve harita aramaları önemlidir.',
    fashion: 'Moda/giyim tarafında görsel performans ve kısa video içerikleri daha yüksek etki yaratabilir.',
    education: 'Eğitim sektöründe arama niyeti ve açıklayıcı video içerikleri daha güçlü sonuç verebilir.',
    technology: 'Teknoloji sektöründe arama reklamları ve bilgilendirici video içerikleri öne çıkarılmıştır.',
    beauty: 'Güzellik/kuaför alanında görsel sosyal medya içerikleri ve yerel aramalar önceliklidir.',
    event: 'Etkinlik kampanyalarında hızlı erişim, sosyal medya görünürlüğü ve lokasyon hedefleme önemlidir.',
    localService: 'Yerel hizmetlerde Google Maps/Search ve yakın çevre hedeflemesi daha yüksek niyetli kullanıcı getirebilir.'
  };
  return texts[sector] || '';
}

function calculateMini(type) {
  if (type === 'cpm') {
    const cost = Number(document.getElementById('cpmCost').value);
    const impressions = Number(document.getElementById('cpmImpressions').value);
    const result = impressions > 0 ? (cost / impressions) * 1000 : 0;
    document.getElementById('cpmResult').textContent = `CPM: ${result ? result.toFixed(2) + ' TL' : '-'}`;
  }
  if (type === 'cpc') {
    const cost = Number(document.getElementById('cpcCost').value);
    const clicks = Number(document.getElementById('cpcClicks').value);
    const result = clicks > 0 ? cost / clicks : 0;
    document.getElementById('cpcResult').textContent = `CPC: ${result ? result.toFixed(2) + ' TL' : '-'}`;
  }
  if (type === 'roi') {
    const revenue = Number(document.getElementById('roiRevenue').value);
    const cost = Number(document.getElementById('roiCost').value);
    const result = cost > 0 ? ((revenue - cost) / cost) * 100 : 0;
    document.getElementById('roiResult').textContent = `ROI: ${cost ? '%' + result.toFixed(1) : '-'}`;
  }
}

document.getElementById('plannerForm').addEventListener('submit', event => {
  event.preventDefault();
  createPlan();
});

['budget', 'goal', 'sector', 'audience', 'duration'].forEach(id => {
  document.getElementById(id).addEventListener('input', createPlan);
});

document.querySelectorAll('[data-calc]').forEach(button => {
  button.addEventListener('click', () => calculateMini(button.dataset.calc));
});

document.getElementById('copyReport').addEventListener('click', async () => {
  const text = document.getElementById('strategyReport').innerText;
  try {
    await navigator.clipboard.writeText(text);
    document.getElementById('copyReport').textContent = 'Kopyalandı';
    setTimeout(() => document.getElementById('copyReport').textContent = 'Metni Kopyala', 1500);
  } catch {
    alert('Kopyalama başarısız oldu. Metni manuel seçip kopyalayabilirsin.');
  }
});

document.getElementById('printReport').addEventListener('click', () => window.print());

createPlan();
